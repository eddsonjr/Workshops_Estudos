//
//  PratoCompradoTableViewCell.swift
//  Basic_MVC_iOS
//
//  Created by Edson  Jr on 06/08/2018.
//  Copyright © 2018 Edson  Jr. All rights reserved.
//

import UIKit

class PratoCompradoTableViewCell: UITableViewCell {

    
    @IBOutlet var nomePratoLabel: UILabel!
    @IBOutlet var dataCompraLabel: UILabel!
    @IBOutlet var valorPratoLabel: UILabel!
    @IBOutlet var nomeCompradorLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
