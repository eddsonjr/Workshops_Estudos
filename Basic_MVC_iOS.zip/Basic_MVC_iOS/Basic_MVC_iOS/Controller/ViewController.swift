//
//  ViewController.swift
//  Basic_MVC_iOS
//
//  Created by Edson  Jr on 06/08/2018.
//  Copyright © 2018 Edson  Jr. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON



class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    
    
    //Mark: variavel com url para baixar lista de pratos
    var url = "https://api.myjson.com/bins/7l8g0"
    
    
    //Mark: variavel para armazenar a lista de pratos baixados
    var listaPratos = [Prato]()
    
    //Mark: variavel para receber o prato que foi selecionado pelo cliente
    var pratoSelecionado: Prato?
    
    //Mark: Elementos gráficos
    @IBOutlet var tableView: UITableView!
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //Conformando os protocolos da tableView
        self.tableView.dataSource = self
        self.tableView.delegate = self
        
        
        
        
        //Baixando a lista de pratos da internet
        baixarListaPratos{ json in
            
            guard let json = json else { return }
           
            //Pegando o json no formato de array
            let jsonArray = json.array
            print("Tamanho do json array: \(String(describing: jsonArray?.count))")
            
            //Percorrendo os elementos desse array de json e fazendo o decode
            for j in jsonArray! {
                let prato = Prato.decode(fromJson: j)
                self.listaPratos.append(prato)
            }
            
            //Atualizando a tableView agora
            self.tableView.reloadData()
            
        }
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    
    
    
    
    //########## FUNCOES PARA CONFORMAR COM OS PROTOCOLOS DE TABLEVIEW ################
    
    func tableView(_ tableView:UITableView, numberOfRowsInSection section:Int) -> Int{
        return self.listaPratos.count
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     
        let cell = tableView.dequeueReusableCell(withIdentifier: "pratoCell") as? PratosTableViewCell
        cell?.nomePratoLabel.text = self.listaPratos[indexPath.row].nome
        cell?.precoPratoLabel.text = String(self.listaPratos[indexPath.row].valor)
        return cell!
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 121
    }
    
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.pratoSelecionado = self.listaPratos[indexPath.row]
        performSegue(withIdentifier: "detalhesPratoSegue", sender: self)
        
    }

    
    
    
    
    
    //############ FUNCAO PARA BAIXAR A LISTA DE PRATOS DA INTERNET ############
    func baixarListaPratos(completion: @escaping (JSON?) -> Void) {
        Alamofire.request(self.url).responseJSON { (responseData) -> Void in
            switch responseData.result {
            case .success(let value): DispatchQueue.main.async { completion(JSON(value)) }
            case .failure(_): completion(nil)
            }
        }
    }
    
    
    
    //############ FUNCAO PARA FAZER A TRANSICAO DE TELA #############
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let detalhesPratoVC = segue.destination as? DetalhesPratoViewController {
            detalhesPratoVC.prato = self.pratoSelecionado
        }
    }
    

}

