//
//  Comprador.swift
//  Basic_MVC_iOS
//
//  Created by Edson  Jr on 06/08/2018.
//  Copyright © 2018 Edson  Jr. All rights reserved.
//

import Foundation
import SwiftyJSON

class Comprador{
    
    var nome: String?
    var endereco: String?
    var telefone: String?
    
    
    init(nome: String!,endereco: String?, telefone: String?) {
        self.nome = nome
        self.endereco = endereco
        self.telefone = telefone
    }
    
    
    
}
