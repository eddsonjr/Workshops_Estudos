//
//  Prato.swift
//  Basic_MVC_iOS
//
//  Created by Edson  Jr on 06/08/2018.
//  Copyright © 2018 Edson  Jr. All rights reserved.
//

import Foundation
import SwiftyJSON

class Prato {
    
    var nome: String!
    var valor: Double!
    var descricao: String!
    
    
    
    init(nome: String!, valor: Double!,descricao: String!) {
        self.nome = nome
        self.valor = valor
        self.descricao = descricao
    }
    
    
    
    //Esta funcao serve somente para decodificar elementos vindos via json
    static func decode(fromJson: JSON) -> Prato {
        print("Decoding... json: \(fromJson)")
        
        return Prato(nome: fromJson["nome"].string!, valor: fromJson["valor"].double!,
                     descricao: fromJson["descricao"].string!)
    }
    
    
}
