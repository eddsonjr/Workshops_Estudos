//
//  CompraPratoViewController.swift
//  Basic_MVC_iOS
//
//  Created by Edson  Jr on 06/08/2018.
//  Copyright © 2018 Edson  Jr. All rights reserved.
//

import UIKit

class CompraPratoViewController: UIViewController {

    //Mark: TextFields
    @IBOutlet var nomeTextField: UITextField!
    @IBOutlet var telefoneTextFeild: UITextField!
    @IBOutlet var enderecoTextField: UITextField!
    
    
    //Mark: prato a ser comprado
    var prato: Prato?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    
    
    
    @IBAction func finalizarCompra(_ sender: Any) {
       let compra = Compra(prato: self.prato, comprador: lerDadosUsuario(), dataCompra: "10/08/2018")
        
        //Adicionando a compra recem feita a lista de compras feitas
        ComprasFeitas.singleton.listaCompras.append(compra)
        print("Total de compras feitas: \(ComprasFeitas.singleton.listaCompras.count)")
        carregarTelaPrincipal()
        
        
    }
    
    
    
    //####### FUNCAO PARA LER OS DADOS ###########
    func lerDadosUsuario() -> Comprador{
        return Comprador.init(nome: self.nomeTextField.text, endereco: self.enderecoTextField.text, telefone: self.telefoneTextFeild.text)
    }
    
    
    //####### FUNCAO PARA CARREGAR A TELA PRINCIPAL DO APP #########
    func carregarTelaPrincipal() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "telaPrincipal") as! ListaPratosViewController
    
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    
  
}
