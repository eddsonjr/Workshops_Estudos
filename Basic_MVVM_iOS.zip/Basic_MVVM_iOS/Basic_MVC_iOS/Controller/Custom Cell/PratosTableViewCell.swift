//
//  PratosTableViewCell.swift
//  Basic_MVC_iOS
//
//  Created by Edson  Jr on 06/08/2018.
//  Copyright © 2018 Edson  Jr. All rights reserved.
//

import UIKit

class PratosTableViewCell: UITableViewCell {

    
    @IBOutlet var nomePratoLabel: UILabel!
    @IBOutlet var precoPratoLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

      
    }

}
