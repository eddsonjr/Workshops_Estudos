//
//  DetalhesPratoViewController.swift
//  Basic_MVC_iOS
//
//  Created by Edson  Jr on 06/08/2018.
//  Copyright © 2018 Edson  Jr. All rights reserved.
//

import UIKit

class DetalhesPratoViewController: UIViewController {

    @IBOutlet var textView: UITextView!
    
    //Mark: Variavel que representa o prato
    var prato: Prato?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.textView.text = getDetalhesPrato()
        
     
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    @IBAction func Comprar(_ sender: Any) {
         performSegue(withIdentifier: "compraPratoSegue", sender: self)
    }
    
    
    
    //####### FUNCAO PARA CRIAR O TEXTO DE DETALHES DO PRTATO ##########
    func getDetalhesPrato() -> String{
        let msg = "\((prato?.nome)!)  \((prato?.descricao)!) Valor:" + String(Double((prato?.valor)!))
        return msg
        
    }
    
    
    
    //############ FUNCAO PARA FAZER A TRANSICAO DE TELA #############
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let compraPratoVC = segue.destination as? CompraPratoViewController {
            compraPratoVC.prato = self.prato
        }
    }
    
    
    
    
}
