//
//  ListaPratosCompradosViewController.swift
//  Basic_MVC_iOS
//
//  Created by Edson  Jr on 06/08/2018.
//  Copyright © 2018 Edson  Jr. All rights reserved.
//

import UIKit

class ListaPratosCompradosViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {

    @IBOutlet var tableView: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.tableView.dataSource = self
        self.tableView.delegate = self
        
        
        
        print("Lista de compras feitas... ")
        print("Total de compras realizadas até o momento: \(ComprasFeitas.singleton.listaCompras.count)")
        
        
        self.tableView.reloadData()
        
        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //########## FUNCOES PARA CONFORMAR COM OS PROTOCOLOS DE TABLEVIEW ################
    
    func tableView(_ tableView:UITableView, numberOfRowsInSection section:Int) -> Int{
        return ComprasFeitas.singleton.listaCompras.count
    }
    
    
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "listaComprasCell") as? PratoCompradoTableViewCell
        
        cell?.nomePratoLabel.text = ComprasFeitas.singleton.listaCompras[indexPath.row].prato.nome
        cell?.valorPratoLabel.text = String(ComprasFeitas.singleton.listaCompras[indexPath.row].prato.valor)
       
        cell?.nomeCompradorLabel.text = ComprasFeitas.singleton.listaCompras[indexPath.row].comprador.nome
        
        return cell!
        
    }
    
    
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 161
    }
    
    

}
