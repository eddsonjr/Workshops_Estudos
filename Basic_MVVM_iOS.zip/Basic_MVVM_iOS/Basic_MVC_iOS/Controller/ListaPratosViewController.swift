//
//  ViewController.swift
//  Basic_MVC_iOS
//
//  Created by Edson  Jr on 06/08/2018.
//  Copyright © 2018 Edson  Jr. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class ListaPratosViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    
    //Mark: variavel para armazenar a lista de pratos baixados
    var listaPratos = [Prato]()
    
    //Mark: variavel para receber o prato que foi selecionado pelo cliente
    var pratoSelecionado: Prato?
    
    //Mark: Elementos gráficos
    @IBOutlet var tableView: UITableView!

    
    //Mark: ViewModel
    var viewModel = ListaPratosViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //Conformando os protocolos da tableView
        self.tableView.dataSource = self
        self.tableView.delegate = self
        
        
        //Baixando a lista de pratos da internet
        self.viewModel.baixarListaPratos{ pratos in
            print("Baixado a quantidade de pratos: \(pratos)")
            self.listaPratos = pratos
            self.tableView.reloadData()
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    
    
    
    
    //########## FUNCOES PARA CONFORMAR COM OS PROTOCOLOS DE TABLEVIEW ################
    
    func tableView(_ tableView:UITableView, numberOfRowsInSection section:Int) -> Int{
        return self.listaPratos.count
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     
        let cell = tableView.dequeueReusableCell(withIdentifier: "pratoCell") as? PratosTableViewCell
        cell?.nomePratoLabel.text = self.listaPratos[indexPath.row].nome
        cell?.precoPratoLabel.text = String(self.listaPratos[indexPath.row].valor)
        return cell!
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 121
    }
    
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.pratoSelecionado = self.listaPratos[indexPath.row]
        performSegue(withIdentifier: "detalhesPratoSegue", sender: self)
        
    }

    
    
    //############ FUNCAO PARA FAZER A TRANSICAO DE TELA #############
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let detalhesPratoVC = segue.destination as? DetalhesPratoViewController {
            detalhesPratoVC.prato = self.pratoSelecionado
        }
    }
    

}

