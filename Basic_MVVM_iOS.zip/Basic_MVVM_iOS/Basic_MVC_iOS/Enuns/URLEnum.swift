//
//  URLEnun.swift
//  Basic_MVVM_iOS
//
//  Created by Edson  Jr on 08/08/2018.
//  Copyright © 2018 Edson  Jr. All rights reserved.
//

import Foundation


enum URLEnum: String {
    case urlListaPrato = "https://api.myjson.com/bins/7l8g0"
}
