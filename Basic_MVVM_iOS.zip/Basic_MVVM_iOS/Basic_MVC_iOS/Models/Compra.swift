//
//  Compra.swift
//  Basic_MVC_iOS
//
//  Created by Edson  Jr on 06/08/2018.
//  Copyright © 2018 Edson  Jr. All rights reserved.
//

import Foundation

class Compra {
    
    var prato: Prato!
    var comprador: Comprador!
    var dataCompra: String!
    
    
    init(prato: Prato!, comprador: Comprador!, dataCompra: String!) {
        self.prato = prato
        self.comprador = comprador
        self.dataCompra = dataCompra
    }
    
    
}
