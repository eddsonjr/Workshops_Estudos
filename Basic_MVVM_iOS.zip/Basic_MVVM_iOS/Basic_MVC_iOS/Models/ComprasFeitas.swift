//
//  ComprasFeitas.swift
//  Basic_MVC_iOS
//
//  Created by Edson  Jr on 06/08/2018.
//  Copyright © 2018 Edson  Jr. All rights reserved.
//

import Foundation

class ComprasFeitas {
    
    
    public static var singleton: ComprasFeitas = ComprasFeitas()
    
    var listaCompras: [Compra] = []
    
}
