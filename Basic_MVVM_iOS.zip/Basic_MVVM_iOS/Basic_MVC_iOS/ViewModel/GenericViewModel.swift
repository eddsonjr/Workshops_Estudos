//
//  ViewModel.swift
//  Basic_MVC_iOS
//
//  Created by Edson  Jr on 08/08/2018.
//  Copyright © 2018 Edson  Jr. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON


class GenericViewModel {
  
    
    //############ FUNCAO PARA BAIXAR A LISTA DE PRATOS DA INTERNET ############
    func baixarJson(completion: @escaping (JSON?) -> Void) {
        Alamofire.request(URLEnum.urlListaPrato.rawValue).responseJSON { (responseData) -> Void in
            switch responseData.result {
            case .success(let value): DispatchQueue.main.async { completion(JSON(value)) }
            case .failure(_): completion(nil)
            }
        }
    }
    
    
    
}

