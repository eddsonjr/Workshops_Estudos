//
//  ListaPratosViewModel.swift
//  Basic_MVVM_iOS
//
//  Created by Edson  Jr on 08/08/2018.
//  Copyright © 2018 Edson  Jr. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

class ListaPratosViewModel: GenericViewModel {
    
    
    private var listaPratos = [Prato]()
    
    func baixarListaPratos(completihonHandler: @escaping ([Prato])->()){
        baixarJson{ json in
            guard let json = json else {return}
            print("Json recebido: \(json)")
            
            //Pegando o json no formato de array
            let jsonArray = json.array
            print("Tamanho do json array: \(String(describing: jsonArray?.count))")
            
            //Percorrendo os elementos desse array de json e fazendo o decode
            for j in jsonArray! {
                let prato = Prato.decode(fromJson: j)
                self.listaPratos.append(prato)
            }
            
            DispatchQueue.main.async {
                completihonHandler(self.listaPratos)
            }
        }
    }
    
    
    
    
}

